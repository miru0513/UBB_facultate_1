import unittest

from src.repository.memrepoclient import MemRepoClient, Client


class MemRepoClientTest(unittest.TestCase):
    def setUp(self):
        self.mem_repo_client = MemRepoClient()
        self.test_client = Client(client_id="123", name="Test Client")

    def test_add(self):
        self.mem_repo_client.add(self.test_client)
        self.assertEquals(self.mem_repo_client.find_by_id("123"), self.test_client)

    def test_add_duplicate(self):
        self.mem_repo_client.add(self.test_client)
        with self.assertRaises(ValueError):
            self.mem_repo_client.add(self.test_client)

    def test_remove(self):
        self.mem_repo_client.add(self.test_client)
        self.mem_repo_client.remove("123")
        self.assertIsNone(self.mem_repo_client.find_by_id("123"))

    def test_remove_nonexistent(self):
        with self.assertRaises(ValueError):
            self.mem_repo_client.remove("123")

    def test_update(self):
        self.mem_repo_client.add(self.test_client)
        updated_client = Client(client_id="123", name="Updated Client")
        self.mem_repo_client.update(updated_client)
        self.assertEquals(self.mem_repo_client.find_by_id("123"), updated_client)

    def test_update_nonexistent(self):
        updated_client = Client(client_id="123", name="Updated Client")
        with self.assertRaises(ValueError):
            self.mem_repo_client.update(updated_client)

    def test_list(self):
        self.mem_repo_client.add(self.test_client)
        self.assertIn(self.test_client, self.mem_repo_client.list())

    def test_find_by_id(self):
        self.mem_repo_client.add(self.test_client)
        self.assertEquals(self.mem_repo_client.find_by_id("123"), self.test_client)

    def test_find_by_id_nonexistent(self):
        self.assertIsNone(self.mem_repo_client.find_by_id("123"))

    def assertEquals(self, param, test_client):
        pass


if __name__ == '__main__':
    unittest.main()
