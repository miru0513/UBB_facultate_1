import unittest

from src.repository.memrepobooks import InMemoryRepository, Book


class InMemoryRepositoryTestCase(unittest.TestCase):
    def setUp(self):
        self.repo = InMemoryRepository()

    def test_add_book(self):
        book = Book('1', 'Title', 'Author')
        self.repo.add(book)
        self.assertEqual(self.repo.find_by_id('1'), book)

    def test_add_existing_book(self):
        book = Book('1', 'Title', 'Author')
        self.repo.add(book)
        with self.assertRaises(ValueError):
            self.repo.add(book)

    def test_remove_book(self):
        book = Book('1', 'Title', 'Author')
        self.repo.add(book)
        self.repo.remove('1')
        self.assertIsNone(self.repo.find_by_id('1'))

    def test_remove_nonexistent_book(self):
        with self.assertRaises(ValueError):
            self.repo.remove('1')

    def test_update_book(self):
        book = Book('1', 'Title', 'Author')
        self.repo.add(book)
        updated_book = Book('1', 'Updated Title', 'Updated Author')
        self.repo.update(updated_book)
        self.assertEqual(self.repo.find_by_id('1'), updated_book)

    def test_update_nonexistent_book(self):
        book = Book('1', 'Title', 'Author')
        with self.assertRaises(ValueError):
            self.repo.update(book)

    def test_list_books(self):
        book1 = Book('1', 'Title1', 'Author1')
        book2 = Book('2', 'Title2', 'Author2')
        self.repo.add(book1)
        self.repo.add(book2)
        self.assertEqual(list(self.repo.list()), [book1, book2])

    def test_find_by_id(self):
        book = Book('1', 'Title', 'Author')
        self.repo.add(book)
        self.assertEqual(self.repo.find_by_id('1'), book)
        self.assertIsNone(self.repo.find_by_id('2'))


if __name__ == '__main__':
    unittest.main()
