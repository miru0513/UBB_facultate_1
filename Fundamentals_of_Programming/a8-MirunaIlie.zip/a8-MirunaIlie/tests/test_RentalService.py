import unittest
from unittest.mock import MagicMock

from src.services.RentalService import RentalService


class TestRentalService(unittest.TestCase):

    def setUp(self):
        self.rental_repo = MagicMock()
        self.client_repo = MagicMock()
        self.book_repo = MagicMock()
        self.rental_service = RentalService(self.rental_repo, self.client_repo, self.book_repo)

    def test_find_by_id_existing(self):
        rental = MagicMock()
        rental.id = 1
        self.rental_repo.__iter__.return_value = iter([rental])
        self.assertEqual(self.rental_service.find_by_id(1), rental)

    def test_find_by_id_non_existent(self):
        rental = MagicMock()
        self.rental_repo.__iter__.return_value = iter([rental])
        self.assertIsNone(self.rental_service.find_by_id(2))

    def test_rent_book(self):
        self.book_repo.find_by_id.return_value = MagicMock()
        self.client_repo.find_by_id.return_value = MagicMock()
        self.rental_repo.is_rented.return_value = False
        self.rental_service.rent_book(1, 1, 1)
        self.rental_repo.add_rental.assert_called_once_with(1, 1, 1)

    def test_rent_book_already_rented(self):
        self.rental_repo.is_rented.return_value = True
        self.assertRaises(ValueError, self.rental_service.rent_book, 1, 1, 1)

    def test_rent_book_non_existent_book(self):
        self.book_repo.find_by_id.return_value = MagicMock()
        self.client_repo.find_by_id.return_value = None
        self.assertRaises(ValueError, self.rental_service.rent_book, 1, 1, 1)

    def test_rent_book_non_existent_client(self):
        self.book_repo.find_by_id.return_value = None
        self.client_repo.find_by_id.return_value = MagicMock()
        self.assertRaises(ValueError, self.rental_service.rent_book, 1, 1, 1)

    def test_return_book(self):
        self.rental_service.return_book(1)
        self.rental_repo.remove_rental.assert_called_once_with(1)


if __name__ == "__main__":
    unittest.main()
