import unittest
from unittest.mock import Mock

from faker import Faker
from src.services.ClientService import ClientService


class TestClientService(unittest.TestCase):

    def setUp(self):
        self.repo_mock = Mock()
        self.fake = Faker()
        self.client_service = ClientService(self.repo_mock)

    def test_add_client(self):
        client_id = self.fake.unique.random_int(min=10000, max=99999)
        name = self.fake.name()
        self.client_service.add_client(client_id, name)
        self.repo_mock.add.assert_called_once()

    def test_list_clients(self):
        self.client_service.list_clients()
        self.repo_mock.list.assert_called_once()

    def test_remove_client(self):
        client_id = self.fake.unique.random_int(min=10000, max=99999)
        self.client_service.remove_client(client_id)
        self.repo_mock.remove.assert_called_once_with(client_id)

    def test_update_client(self):
        client_id = self.fake.unique.random_int(min=10000, max=99999)
        name = self.fake.name()
        self.client_service.update_client(client_id, name)
        self.repo_mock.update.assert_called_once()

    def test_generate_clients(self):
        number_of_clients = 5
        self.client_service.generate_clients(number_of_clients)
        assert self.repo_mock.add.call_count == number_of_clients




if __name__ == '__main__':
    unittest.main()
