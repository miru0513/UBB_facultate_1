import unittest
from unittest.mock import Mock

from src.services.Book_service import BookService


class TestBookService(unittest.TestCase):

    def setUp(self):
        self.mock_repo = Mock()
        self.book_service = BookService(self.mock_repo)

    def test_add_book(self):
        self.book_service.add_book(1, 'Title', 'Author')
        self.mock_repo.add.assert_called_once()

    def test_list_books(self):
        self.book_service.list_books()
        self.mock_repo.list.assert_called_once()

    def test_remove_book(self):
        self.book_service.remove_book(1)
        self.mock_repo.remove.assert_called_once_with(1)

    def test_update_book(self):
        self.book_service.update_book(1, 'Title', 'Author')
        self.mock_repo.update.assert_called_once()

    def test_generate_books(self):
        self.book_service.generate_books(5)
        self.assertEqual(self.mock_repo.add.call_count, 5)


    def test_find_by_id(self):
        mock_book = Mock()
        mock_book.book_id = 1
        self.mock_repo.list.return_value = [mock_book]
        self.assertEqual(self.book_service.find_by_id(1), mock_book)


if __name__ == '__main__':
    unittest.main()
