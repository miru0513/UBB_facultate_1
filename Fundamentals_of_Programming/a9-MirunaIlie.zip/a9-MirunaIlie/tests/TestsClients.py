import unittest
from unittest.mock import MagicMock
from src.domain.client import Client
from src.services.ClientService import ClientService
from src.repository.memrepoclient import MemRepoClient
from src.exceptions.exception_repo import RepositoryException

class TestMemRepoClient(unittest.TestCase):

    def setUp(self):
        """Create a new MemRepoClient instance for each test."""
        self.repo = MemRepoClient()

    def test_add_client_success(self):
        """Test adding a client to the repository."""
        client = Client(client_id=1, name="John Doe")
        self.repo.add_client(client)
        self.assertEqual(len(self.repo._data), 1)
        self.assertIn("1", self.repo._data)  # Client ID should be the key
        self.assertEqual(self.repo._data["1"].name, "John Doe")

    def test_add_client_failure(self):
        """Test adding a client with an existing ID."""
        client = Client(client_id=1, name="John Doe")
        self.repo.add_client(client)
        with self.assertRaises(RepositoryException) as context:
            self.repo.add_client(client)  # Trying to add a client with the same ID again
        self.assertEqual(str(context.exception), "Client with this ID already exists.")

    def test_remove_client_success(self):
        """Test removing a client by their ID."""
        client = Client(client_id=1, name="John Doe")
        self.repo.add_client(client)
        self.repo.remove_client("1")
        self.assertEqual(len(self.repo._data), 0)
        self.assertNotIn("1", self.repo._data)  # Client should be removed

    def test_remove_client_failure(self):
        """Test removing a client with a non-existent ID."""
        with self.assertRaises(RepositoryException) as context:
            self.repo.remove_client("999")  # Client with ID 999 doesn't exist
        self.assertEqual(str(context.exception), "Client with this ID doesn't exist.")

    def test_update_client_success(self):
        """Test updating an existing client's details."""
        client = Client(client_id=1, name="John Doe")
        self.repo.add_client(client)
        updated_client = Client(client_id=1, name="Jane Doe")
        self.repo.update_client(updated_client)
        self.assertEqual(self.repo._data["1"].name, "Jane Doe")  # The name should be updated

    def test_update_client_failure(self):
        """Test updating a non-existent client."""
        client = Client(client_id=999, name="Non Existent")
        with self.assertRaises(RepositoryException) as context:
            self.repo.update_client(client)
        self.assertEqual(str(context.exception), "Client with the given ID does not exist.")

    def test_find_by_id_client_success(self):
        """Test finding a client by their ID."""
        client = Client(client_id=1, name="John Doe")
        self.repo.add_client(client)
        found_client = self.repo.find_by_id_client("1")
        self.assertEqual(found_client.name, "John Doe")

    def test_find_by_id_client_failure(self):
        """Test trying to find a non-existent client."""
        found_client = self.repo.find_by_id_client("999")
        self.assertIsNone(found_client)  # Should return None as the client doesn't exist

    def test_list_client(self):
        """Test listing all clients."""
        client1 = Client(client_id=1, name="John Doe")
        client2 = Client(client_id=2, name="Jane Doe")
        self.repo.add_client(client1)
        self.repo.add_client(client2)
        clients = list(self.repo.list_client())
        self.assertEqual(len(clients), 2)
        self.assertEqual(clients[0].name, "John Doe")
        self.assertEqual(clients[1].name, "Jane Doe")

if __name__ == "__main__":
    unittest.main()
