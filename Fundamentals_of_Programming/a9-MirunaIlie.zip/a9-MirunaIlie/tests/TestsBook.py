import unittest
from unittest.mock import MagicMock

from src.domain.book import Book
from src.domain.rental import Rental
from src.exceptions.exception_service import ServiceException
from src.repository.memreporental import RentalMemoryRepository
from src.services.Book_service import BookService
from src.repository.memrepobooks import InMemoryRepository
from src.exceptions.exception_repo import RepositoryException
from src.services.UndoService import Operation, FunctionCall, UndoService


class TestInMemoryRepository(unittest.TestCase):

    def setUp(self):
        # Initialize the repository for each test
        self.repo = InMemoryRepository()
        self.book1 = Book("1", "Book Title 1", "Author 1")
        self.book2 = Book("2", "Book Title 2", "Author 2")

    def test_add_book(self):
        # Test adding a book
        self.repo.add_book(self.book1)
        self.assertEqual(len(self.repo.list_book()), 1)
        self.assertIn(self.book1, self.repo.list_book())

        # Test adding a book with duplicate ID
        with self.assertRaises(RepositoryException):
            self.repo.add_book(self.book1)

    def test_find_by_id_book(self):
        # Test finding a book by ID
        self.repo.add_book(self.book1)
        self.assertEqual(self.repo.find_by_id_book("1"), self.book1)

        # Test finding a non-existent book
        self.assertIsNone(self.repo.find_by_id_book("999"))

    def test_remove_book(self):
        # Test removing a book
        self.repo.add_book(self.book1)
        self.repo.remove_book("1")
        self.assertEqual(len(self.repo.list_book()), 0)

        # Test removing a non-existent book
        with self.assertRaises(RepositoryException):
            self.repo.remove_book("999")

    def test_update_book(self):
        # Test updating a book
        self.repo.add_book(self.book1)
        updated_book = Book("1", "Updated Title", "Updated Author")
        self.repo.update_book(updated_book)

        # Verify the book was updated
        book = self.repo.find_by_id_book("1")
        self.assertEqual(book.title, "Updated Title")
        self.assertEqual(book.author, "Updated Author")

        # Test updating a non-existent book
        non_existent_book = Book("999", "Non-existent", "Author")
        with self.assertRaises(RepositoryException):
            self.repo.update_book(non_existent_book)

    def test_list_book(self):
        # Test listing books
        self.repo.add_book(self.book1)
        self.repo.add_book(self.book2)
        books = list(self.repo.list_book())

        self.assertEqual(len(books), 2)
        self.assertIn(self.book1, books)
        self.assertIn(self.book2, books)


if __name__ == "__main__":
    unittest.main()
