def leap_year(year):
    ok=0
    #A year is a leap year if it's divisible by 4 but not by 100, or if it's divisible by 400
    #for example 1800 is divisible by 4 and 100 ,but not by 400 so it's not a leap year
    if year%4==0 and year%100!=0 or year%400==0:
        ok=1
    return ok

def all_years(y1,y2):
    count=0
    for i in range(y2+1,y1):
        if(leap_year(i)==1):
            count=count+366
        else:
            count=count+365
    return count

def current_year(y1,m1,d1):
    count=0
    count=count+d1;
    for i in range(1,m1-1):
        if i==2 and leap_year(i)==1:
            count=count+29
        elif i==2 and leap_year(i)==0:
            count=count+28
        elif i<=7:
            if i%2!=0:
                count=count+31
            else:
                count=count+30
        elif i>7:
            if i % 2 == 0:
                count = count + 31
            else:
                count = count + 30
    return count


def birth_year(y2,m2,d2):
    count = 0
    for i in range(1,m2-1):
        if i==2 and leap_year(i)==1:
            count=count+29
        elif i==2 and leap_year(i)==0:
            count=count+28
        elif i<7:
            if i%2!=0:
                count=count+31
            else:
                count=count+30
        elif i>7:
            if i % 2 == 0:
                count = count + 31
            else:
                count = count + 30

    if(leap_year(y2)==1):
        return 366-count
    else:
        return 365-count



d1=int(input("Please introduce current day "))
m1=int(input("Please introduce current month "))
y1=int(input("Please introduce current year "))
d2=int(input("Please introduce the day of your birth " ))
m2=int(input("Please introduce the month of your birth "))
y2=int(input("Please introduce year of your birth "))
print(all_years(y1,y2)+current_year(y1,m1,d1)+birth_year(y2,m2,d2))

